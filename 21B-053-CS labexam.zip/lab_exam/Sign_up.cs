﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_exam
{
    public partial class Sign_up : Form
    {
        public Sign_up()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\OneDrive\Documents\Event MS.mdf;Integrated Security=True;Connect Timeout=30");

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("Insert into employees (username , firstname , lastname , email , password , phone , Type ) values(@a , @b , @c , @d , @e , @f, @g)", Con);
                cmd.Parameters.AddWithValue("@a", textBox4.Text);
                cmd.Parameters.AddWithValue("@b", textBox1.Text);
                cmd.Parameters.AddWithValue("@c", textBox2.Text);
                cmd.Parameters.AddWithValue("@d", textBox3.Text);
                cmd.Parameters.AddWithValue("@e", textBox5.Text);
                cmd.Parameters.AddWithValue("@f", textBox7.Text);
                cmd.Parameters.AddWithValue("@g", textBox8.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Your account have been created successfully");
                Con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }
    }
}
