﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_exam
{
    public partial class deshboard : Form
    {
        public deshboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            deshboard temp = new deshboard();
            temp.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insert temp=new insert();
            temp.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            update temp = new update();
            temp.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            delete temp = new delete();
            temp.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            select temp = new select();
            temp.Show();
            this.Hide();
        }
    }
}
