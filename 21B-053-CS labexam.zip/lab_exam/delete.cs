﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_exam
{
    public partial class delete : Form
    {
        public delete()
        {
            InitializeComponent();
            DisplayEvent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\OneDrive\Documents\Event MS.mdf;Integrated Security=True;Connect Timeout=30");
        private void DisplayEvent()
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM projects", Con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                System.Data.DataTable table = new System.Data.DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            deshboard temp = new deshboard();
            temp.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insert temp = new insert();
            temp.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            update temp=new update();
            temp.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            delete temp = new delete();
            temp.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            select temp = new select();
            temp.Show();
            this.Hide();
        }

        private void delete_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.Show();
            this.Hide();
        }
    }
}
